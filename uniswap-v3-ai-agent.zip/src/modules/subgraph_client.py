# src/modules/subgraph_client.py
import logging
from typing import List, Dict, Any, Optional
from gql import gql, Client
from gql.transport.requests import RequestsHTTPTransport
from core.config import settings

logger = logging.getLogger(__name__)

# Este es el ID del subgraph oficial de Uniswap V3 en Mainnet.
# Lo usaremos para construir la URL del nuevo Gateway.
UNISWAP_V3_SUBGRAPH_ID = "0x9a7a6d51c925c4a7e94e8a1a2b3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1"

class SubgraphClient:
    def __init__(self, chain: str, api_key: Optional[str] = None):
        if chain != "eth":
            # El nuevo gateway es más complejo para otras cadenas, nos enfocamos en mainnet por ahora.
            raise NotImplementedError(f"La cadena '{chain}' aún no está soportada por el nuevo SubgraphClient.")

        if not api_key:
            raise ValueError("Se requiere una API Key de The Graph para usar el nuevo Gateway.")

        # Construimos la URL del nuevo Gateway de The Graph
        url = f"https://gateway-arbitrum.network.thegraph.com/api/{api_key}/subgraphs/id/{UNISWAP_V3_SUBGRAPH_ID}"
        
        transport = RequestsHTTPTransport(url=url, retries=3, timeout=30)
        # Ya no necesitamos headers de autorización, la clave está en la URL
        self.client = Client(transport=transport, fetch_schema_from_transport=False) 
        logger.info(f"SubgraphClient inicializado para la cadena '{chain}' usando el Gateway de The Graph.")

    def get_positions_for_wallet(self, owner_address: str) -> List[Dict[str, Any]]:
        """Obtiene las posiciones activas para una wallet (con liquidez > 0)."""
        query = gql("""
            query($owner: String!) {
                positions(where: {owner: $owner, liquidity_gt: 0}) {
                    id
                    pool { id, token0 { symbol }, token1 { symbol }, token0Price }
                    tickLower { tickIdx, price0 }
                    tickUpper { tickIdx, price0 }
                }
            }
        """)
        params = {"owner": owner_address.lower()}
        
        try:
            result = self.client.execute(query, variable_values=params)
            
            # El nuevo Gateway puede devolver `{"data": null}` si no hay nada, en lugar de una lista vacía.
            if not result or not result.get('positions'):
                positions = []
            else:
                positions = result.get('positions', [])

            logger.info(f"Subgraph query exitosa. Se encontraron {len(positions)} posiciones activas para la wallet {owner_address}")
            return positions
        except Exception as e:
            logger.error(f"Error al consultar el Subgraph: {e}", exc_info=True)
            return []

# La instancia global ahora fallará si no hay API key, lo cual es más seguro.
subgraph_client = SubgraphClient(chain=settings.CHAIN, api_key=settings.THEGRAPH_API_KEY)

