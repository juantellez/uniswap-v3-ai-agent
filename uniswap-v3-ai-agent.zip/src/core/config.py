# src/core/config.py
import os
from typing import Optional
from pydantic import BaseSettings
import logging
logger = logging.getLogger(__name__)

if settings.THEGRAPH_API_KEY:
    logger.info("API Key de The Graph cargada exitosamente desde .env.")
else:
    logger.warning("No se encontró la API Key de The Graph en .env. Las consultas a The Graph fallarán.")

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

class Settings(BaseSettings):
    # --- Database ---
    DATABASE_URL: str = f"sqlite:///{os.path.join(PROJECT_ROOT, 'src/data/agent.db')}"

    # --- Scheduler ---
    SCAN_INTERVAL_SECONDS: int = 3600

    # --- Development ---
    DEV_MODE_MOCK_API: bool = False

    # --- AI Agent ---
    MODEL_PATH: str = os.path.join(PROJECT_ROOT, "models/llm/qwen3-4b-q8_0.gguf")
    N_GPU_LAYERS: int = 0
    
    # --- Blockchain ---
    CHAIN: str = "eth"
    THEGRAPH_API_KEY: Optional[str] = None # <--- ¡LA LÍNEA QUE FALTABA!

    # --- Notifications ---
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_CHAT_ID: Optional[str] = None

    class Config:
        env_file = os.path.join(PROJECT_ROOT, ".env")

settings = Settings()